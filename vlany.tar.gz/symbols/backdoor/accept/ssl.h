SSL_CTX *ctx;
SSL *ssl;
